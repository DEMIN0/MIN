const cache = require('utils/cache.js');
const VERSION = 164;
App({

  onLaunch: function () {
    cache.checkLimit();
    const res = wx.getSystemInfoSync();
    if (res.windowHeight > 750) this.globalData.isAllScreen = true;
  },

  globalData: {
    isAllScreen:false,
      playIdx: -1,
      videos: [],
    firstPlay: true,
    playName: '多多早教',
    picsrc: 'https://cdngamebd.ergeduoduo.com/ddedu/audio_cover.png',
    playTime: '00:00',
    playDuration: '00:00',
    progress: 0,
    isPlaying: false,
    
    version: VERSION,
    videoListId: 29,
    baseUrl2: 'https://bb.ergeduoduo.com/baby/wxapp.php?wxg=1' + "&ver=" + VERSION,
    baseUrl: 'https://bb.ergeduoduo.com/baby/bb.php?wxg=1' + "&ver=" + VERSION,

    baseUrlZ: 'https://edu.ergeduoduo.com/ddedu/api/v1/list.php?act=getalbumlist&pid=46&pg=0&ps=30',

    shareTitle: '多多早教—趣味课件，国学才艺，英语启蒙',
    shareImg: 'https://cdngamebd.ergeduoduo.com/ddedu/ddedu-share.jpg',
  },
 

  methods: {
    adjustList: function (list, pageNum) {
      //map() 方法创建一个新数组，其结果是该数组中的每个元素都调用一次提供的函数后的返回值。
      return list.map(video => {
        let playcnt = video.playcnt;
        if (playcnt > 10000 * 10000) {
          playcnt = (playcnt / 10000 / 10000).toFixed(2) + "亿";
        } else if (playcnt > 10000) {
          playcnt = (playcnt / 10000).toFixed(1) + '万';
        }
        video.playcnt = playcnt;
        video.pagenum = pageNum;
        return video;
      });
    },
  }
  
})