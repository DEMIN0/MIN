// pages/vplayer/vplayer.js

const reqMgr = require('../../utils/reqmgr.js');
const app = getApp();
Page({

  data: {
    pageNum: 1,
    src: '',
    hasMore: 1,
    loading: false,
    playId: -1,
    playIdx: -1,
    videos: [],
    errortry: 0,
    video_container_style: "",
    toView:"demo",
  },
  properties: {
    pageId: 29,
    pageNum: 0,
    shareInfo: null
  },

  onLoad: function (options) {

   
    const amgr = wx.getBackgroundAudioManager();
    if (!!amgr) {
      amgr.pause();
    }
    
    try {
      const res = wx.getSystemInfoSync();
      // console.info(res);
      //视频高度
      let vh = Math.round(9 * res.windowWidth / 16);

      this.setData({
        video_container_style: "height:" + vh.toString() + "px;"
      });
    } catch (e) {
      console.log(e);
    }

    // console.info(options);

    let vlist = [];
    
    if (options.videos) {
      try {
        // console.info('22222')
        vlist = JSON.parse(decodeURIComponent(options.videos));
          // console.info(vlist)
      } catch (e) {
        vlist = [];
      }
    }
    // console.info('options.hasmore:' + options.hasmore);
    let hasmore = options.hasmore || 1;
    // console.info(hasmore);
    this.setData({
      playId: options.rid,
      videos: vlist,
      hasMore: hasmore,
    });
    
    this.properties.pageId = options.pid || 0;
    this.properties.pageNum = options.pn || 0;
    console.info('pageNum:'+ this.properties.pageNum);
    let index = options.index || 0;
    if (vlist.length > 0 && index < vlist.length) {
      this.playWithUrl(vlist[index].downurl, index, vlist[index].id);
    } 
    // else {
    //   this.playWithRid(options.rid);
    // }
    // if (vlist.length == 0) {
    //   this.getList();
    // }
    this.toView = 'demo'+vlist[index].id;
    this.setData({
      toView: 'demo' + vlist[index].id
    });
    console.info('this.toid:' + this.toView);
  },

  onReachBottom: function () {
    
    if (this.canLoadMore(0)) {

      console.info('bottom');
      this.loadMore();
    }
  },

  canLoadMore: function () {
    if (this.data.hasMore==0){
      return false;
    }else{
      return true;
    }
    
  },

  loadMore: function () {
    if (this.canLoadMore(0)) {
      // this.properties.pageNum++;
    this.getList();
    this.setData({
      errortry: 0
    });
    }
  },

  getList: function () {
    if (this.canLoadMore()) {
      this.setData({
        loading: true,
      });
       console.info(this.properties.pageNum);
      reqMgr.video.getListL({
        pageId: this.properties.pageId,
        // pageNum: this.data.pageNum,
        pageNum: this.properties.pageNum,
        reqComplete: this.getListCB
      });
    }
  },
  getListCB: function (res) {
    let neterror = 0;
    // if (res.data && res.data.list) {
    if (res.data && res.data.list) {
      console.info('ssss');
      this.parseList(res);
    } else {
      // console.info('sdadad');
      // this.parseListT(res);
    }

    this.setData({
      loading: false,
      errortry: neterror
    });
  },
  parseList: function (res) {
    // let pageNum = this.data.pageNum;
    let pageNum = this.properties.pageNum;
    console.info('pageNum:' + pageNum);
    let videos = this.data.videos;
    let list = res.data.list;
    let pinfo = list[0];
    //  console.info(pinfo);
    let newVideos = app.methods.adjustList(list, pageNum);
    //let newVideos = list;
    let pageData = {
      'pageNum': pageNum + 1,
      'hasMore': res.data.hasmore,
      'videos': videos.concat(newVideos)
    }
    this.properties.pageNum++;
    this.setData(pageData);
  },

  playWithUrl(url, index, playid) {
    this.setData({
      src: url,
      playIdx: parseInt(index),
      playId: playid,
    });
  },

  playVideo: function (event) {
    let idx = event.currentTarget.dataset.idx;
    this.playByIdx(idx);
    // wx.pageScrollTo({
    //   scrollTop: 0,
    //   duration: 3000
    // });
  },
  playByIdx: function (idx) {
    let videos = this.data.videos;
    if (idx >= videos.length) {
      idx = 0;
    }
    let info = videos[idx];
    this.setData({
      playId: info.id,
      playIdx: idx
    });
    // this.properties.shareInfo = info;
    // wx.updateShareMenu();
    this.playWithRid(info.id);
  },

  playWithRid: function (rid) {
    console.info('rid:'+rid);
    let page = this;
    reqMgr.video.getPlayUrl(rid, function (res) {
      if (res.statusCode == 200 && res.data) {
        console.info(res);
        page.setData({
          src: res.data
        });
      }
      wx.hideLoading();
    });
  },

  playNext: function () {
    var idx = this.data.playIdx;
    if (idx !== -1) {
      this.playByIdx(idx + 1);
    }
  },
  playEnded: function (event) {
    this.playNext();
  },

  buildShareUrl: function () {
    let url = '/pages/videos/videos?';
    return url;
  },
  buildShareImg: function () {
    return app.globalData.shareImg;
  },
  buildShareTitle: function () {
    return app.globalData.shareTitle;
  },
  onShareAppMessage: function (options) {
    return {
      title: this.buildShareTitle(),
      path: this.buildShareUrl(),
      imageUrl: this.buildShareImg()
    };
  },

})