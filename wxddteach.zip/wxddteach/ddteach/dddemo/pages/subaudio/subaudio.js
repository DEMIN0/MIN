const reqMgr = require('../../utils/reqmgr.js');
const app = getApp();

let subPages = [{
  name: '儿歌',
  type: 'audio',
  pageId: 5,
  pageNum: 0,
  hasMore: 1,
  loading: false,
  playIdx: -1,
  videos: [],
  albums: []
}
];
Page({
  data: {
    pName:'',
    currentTab: 0,
    playTab: 0,
    subPages: subPages,
    playName: '多多早教',
    playTime: '00:00',
    playDuration: '00:00',
    progress: 0,
    isPlaying: false,
    errortry: 0,
    picsrc: 'https://cdnwebhlt.shoujiduoduo.com/bama/mp/audio_cover.png',
    // tabWidth:0,
    // tabOffset:0,
    // indicatorAnim: {},
    changePage:0,
  },
  properties: {
    shareInfo: null,
    pageId:0,
    pic:null,
  },
  onLoad: function (options) {
    
    this.changePage = 0;
    this.pName= options.pName;
    
    this.setData(
      this.changePage,
    );
    this.setData({
      pName:options.pName
    })
    console.info('pName:'+this.pName);
    this.properties.pageId=options.pid;
    
    this.getList();
    if ((options['type'] || '') === 'share') {
      this.dealShareUrl(options);
    }
  },
  onShow:function(){
    this.setData({
      playName: app.globalData.playName,
      picsrc: app.globalData.picsrc,
      playTime: app.globalData.playTime,
      playDuration: app.globalData.playDuration,
      progress: app.globalData.progress,
      isPlaying: app.globalData.isPlaying,
    });
  },


  dealShareUrl(options) {
    const amgr = wx.getBackgroundAudioManager();
    amgr.title = (options['name'] || '多多早教');
    amgr.singer = (options['artist'] || '多多早教');
    this.setData({
      playName: options['name'] || '多多早教'
    })
    amgr.coverImgUrl = 'https://cdnwebhlt.shoujiduoduo.com/bama/mp/audio_cover.png'
    amgr.src = decodeURIComponent(options['url']);
  },

  onReady: function () {
    const amgr = wx.getBackgroundAudioManager();

    console.info(amgr);

    amgr.onTimeUpdate(this.onTimeUpdate);
    amgr.onEnded(this.onEnded);
    const paused = amgr.paused;
    if (app.globalData.firstPlay == false) {
      this.setData({
        isPlaying: !paused
      });
    }
  },
  onReachBottom: function () {
    if (this.canLoadMore()) {
      this.loadMore();
    }
  },
  //viewPager
  swichNav: function (e) {
    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      this.setData({
        currentTab: e.target.dataset.current
      });
    }
  },
  onPageChange: function (e) {
    let index = e.detail.current;
    let videos = this.getSubPageVideos(index);
    if (videos.length === 0) {
      setTimeout(this.getList, 300, index);
      // this.getList(index);
    }
    if (this.data.currentTab != index) {
      this.setData({
        currentTab: index
      });
    }
  },
  getSubPageNum: function (index) {
    if (typeof index === 'undefined') {
      index = this.data.currentTab;
    }
    return this.data.subPages[index].pageNum;
  },
  getSubPageMore: function (index) {
    if (typeof index === 'undefined') {
      index = this.data.currentTab;
    }
    return this.data.subPages[index].hasMore;
  },
  getSubPageLoading: function (index) {
    if (typeof index === 'undefined') {
      index = this.data.currentTab;
    }
    return this.data.subPages[index].loading;
  },
  getSubPagePlayIdx: function (index) {
    if (typeof index === 'undefined') {
      index = this.data.currentTab;
    }
    return this.data.subPages[index].playIdx;
  },
  canLoadMore: function (index) {
    if (typeof index === 'undefined') {
      index = this.data.currentTab;
    }
    return this.getSubPageMore(index) && !this.getSubPageLoading(index);
  },
  getSubPageVideos: function (index) {
    if (typeof index === 'undefined') {
      index = this.data.currentTab;
    }
    return this.data.subPages[index].videos;
  },
  setSubPageData: function (info, index) {
    if (typeof index === 'undefined') {
      index = this.data.currentTab;
    }
    let baseKey = 'subPages[' + index + '].';
    let newData = {};
    for (let key in info) {
      let k = baseKey + key;
      newData[k] = info[key];
    }
    this.setData(newData);
  },
  parseList: function (res, listId) {
    console.info('LLLLLd: '+listId);
    let pageNum = this.getSubPageNum(listId);
    let videos = this.getSubPageVideos(listId);
    let list = res.data.list;
    let pinfo = list.shift();
    let newVideos = app.methods.adjustList(list, pageNum);
    let pageData = {
      'pageNum': pageNum + 1,
      'hasMore': pinfo.hasmore,
      'videos': videos.concat(newVideos)
    }
    console.info(this.videos);
    
    this.setSubPageData(pageData, listId);
    
  },
  getListCB: function (res, listId) {
    let neterror = 0;
    if (res.data && res.data.list) {
      this.parseList(res, listId);
    } else {
      neterror = 1;
    }
    this.setSubPageData({
      loading: false,
      errortry: neterror
    }, listId);
  },
  getList: function (index) {
    if (typeof index === 'undefined') {
      index = this.data.currentTab;
    }
    if (this.canLoadMore()) {
      this.setSubPageData({
        loading: true
      }, index);
      // console.info('LLLLLd: ' + index);
      reqMgr.audio.getList({
       
        pageId:this.properties.pageId,
        pageNum: this.getSubPageNum(index),
        listId: index,
        reqComplete: this.getListCB
      });
    }
  },
  loadMore: function () {
    // console.info('MMMMMMMM');
    this.getList();
    this.setSubPageData({
      errortry: 0
    });
  },
  playAudio: function (event) {

    app.globalData.firstPlay=false;
    this.changePage=1;
    this.setData({
      changePage:1,
    }
    );
    console.info('changePage:' + this.changePage);
    let idx = event.currentTarget.dataset.idx;

   
    app.globalData.videos = this.getSubPageVideos(0),
      app.globalData.playIdx= idx,
  
    // console.info(idx);
    this.playByIdx(idx);
   
  },
  playByIdx: function (idx) {
    // let videos = this.getSubPageVideos();
    let videos = app.globalData.videos;
    if (idx >= videos.length) {
      idx = 0;
      app.globalData.playIdx=0;
    }
    let info = videos[idx];
    if (!info) {
      return;
    }
    this.setSubPageData({
      playIdx: idx
    });
    const amgr = wx.getBackgroundAudioManager();
    amgr.title = info.name;
    amgr.singer = info.artist;
    // amgr.coverImgUrl = 'http://cdnwebhlt.shoujiduoduo.com/bama/mp/audio_cover.png'
      amgr.coverImgUrl = 'https:\/\/cdnbbbd.ergeduoduo.com\/bb\/img\/album\/m750x750\/' + this.properties.pageId.slice(-3)+'\/'+this.properties.pageId+'.jpg';
   
    amgr.src = info.url;
    
    this.setData({
      playTab: this.data.currentTab,
      playName: info.name,
      isPlaying: true,
      // picsrc: 'http:\/\/cdnbbbd.ergeduoduo.com\/bb\/img\/album\/m750x750\/' + this.properties.pageId.slice(-3) + '\/' + this.properties.pageId +'.jpg',
    });
    if(this.changePage==1){
      this.setData({
        picsrc: 'https:\/\/cdnbbbd.ergeduoduo.com\/bb\/img\/album\/m750x750\/' + this.properties.pageId.slice(-3) + '\/' + this.properties.pageId + '.jpg',
      });

      // app.globalData.playName = info.name;
      app.globalData.picsrc = 'https:\/\/cdnbbbd.ergeduoduo.com\/bb\/img\/album\/m750x750\/' + this.properties.pageId.slice(-3) + '\/' + this.properties.pageId + '.jpg';

      // app.globalData.isPlaying = true;
    }

    app.globalData.playName = info.name;
    // app.globalData.picsrc = 'http:\/\/cdnbbbd.ergeduoduo.com\/bb\/img\/album\/m750x750\/' + this.properties.pageId.slice(-3) + '\/' + this.properties.pageId + '.jpg';

    app.globalData.isPlaying = true;
    

   
   
   

  },

  
  playNext: function () {
    console.info('playNexttttt!');
    // var idx = this.getSubPagePlayIdx(this.data.playTab);
    var idx = (app.globalData.playIdx++);
    console.info(idx);
    if (idx !== -1) {
      this.playByIdx(idx+1);
    }
  },
  play: function () {
    const amgr = wx.getBackgroundAudioManager();
    console.info(amgr);
    if (amgr.src) {
      amgr.play();
      this.setData({
        isPlaying: true
      });
    } else {
      var idx = (app.globalData.playIdx);

      if (idx !== -1) {
        console.info(idx);
        this.playByIdx(idx);
        // wx.getBackgroundAudioManager().startTime 
      }
    }
  },
  pause: function () {
    const amgr = wx.getBackgroundAudioManager();
    amgr.pause();
    this.setData({
      isPlaying: false
    });
  },
  formatTime: function (time) {
    let ret = '';
    let minute = parseInt(time / 60);
    let second = parseInt(time % 60);
    ret = minute > 10 ? minute : '0' + minute;
    ret += ':';
    ret += second > 9 ? second : '0' + second;
    return ret;
  },
  onTimeUpdate: function () {
    const amgr = wx.getBackgroundAudioManager();
    let ndata = {
      playTime: this.formatTime(amgr.currentTime),
      playDuration: this.formatTime(amgr.duration),
    };
    let progress = parseInt(amgr.currentTime * 100 / amgr.duration);
    ndata.progress = progress;
    app.globalData.playTime = this.formatTime(amgr.currentTime);
    app.globalData.playDuration = this.formatTime(amgr.duration);
    app.globalData.progress = progress;
    this.setData(ndata);
    
  },
  onEnded: function () {
    this.playNext();
  },
  onSliderChange: function (event) {
    const value = event.detail.value;
    const amgr = wx.getBackgroundAudioManager();
    let time = parseInt(amgr.duration * value / 100);
    amgr.seek(time);
  },
  buildShareUrl: function () {
    let url = '/pages/audios/audios?';
    let info = this.properties.shareInfo;
    if (info) {
      url += 'rid=' + info.id;
      url += '&name=' + info.name;
      url += '&artist=' + info.artist;
      url += '&url=' + encodeURIComponent(info.downurl);
      url += '&type=share';
    }
    return url;
  },
  buildShareImg: function () {
    return app.globalData.shareImg;
  },
  buildShareTitle: function () {
    let info = this.properties.shareInfo;
    if (info) {
      return info.name;
    }
    return app.globalData.shareTitle;
  },
  onShareAppMessage: function (options) {
    return {
      title: this.buildShareTitle(),
      path: this.buildShareUrl(),
      imageUrl: this.buildShareImg()
    };
  },

})