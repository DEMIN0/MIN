
const app = getApp();
const reqMgr = require('../../utils/reqmgr.js');
Page({
  data: {
    playName: '多多早教',
    picsrc: 'https:\/\/cdnbbbd.ergeduoduo.com\/bb\/img\/album\/m750x750\/405\/57405.jpg',
    playTime: '00:00',
    playDuration: '00:00',
    progress: 0,
    isPlaying: false,

    hasMore: 1,
    loading: false,
    videos: [],
  },
  properties: {
    pageId: 46,
    pageNum: 0,
  },
  onLoad: function (options) {
    this.properties.pageId=options.pid;
    console.info('11111');
    this.getList();
  },
  onReady: function () {
    const amgr = wx.getBackgroundAudioManager();

    console.info(amgr);

    amgr.onTimeUpdate(this.onTimeUpdate);
    amgr.onEnded(this.onEnded);
    const paused = amgr.paused;
    if (app.globalData.firstPlay == false) {
      this.setData({
        isPlaying: !paused
      });
    }

  },
  onShow: function () {
    console.info('2222');
    this.setData({
      playName: app.globalData.playName,
      picsrc: app.globalData.picsrc,
      playTime: app.globalData.playTime,
      playDuration: app.globalData.playDuration,
      progress: app.globalData.progress,
      isPlaying: app.globalData.isPlaying,
    });

    const amgr = wx.getBackgroundAudioManager();

    console.info(amgr);

    amgr.onTimeUpdate(this.onTimeUpdate);
    amgr.onEnded(this.onEnded);
    const paused = amgr.paused;
    if (app.globalData.firstPlay == false) {
      this.setData({
        isPlaying: !paused
      });
    }
  },

  onReachBottom: function () {
    console.info('onReachBottom');
    if (this.canLoadMore()) {
      this.loadMore();
    }
  },

  formatTime: function (time) {
    let ret = '';
    let minute = parseInt(time / 60);
    let second = parseInt(time % 60);
    ret = minute > 10 ? minute : '0' + minute;
    ret += ':';
    ret += second > 9 ? second : '0' + second;
    return ret;
  },
  onTimeUpdate: function () {
    const amgr = wx.getBackgroundAudioManager();
    let ndata = {
      playTime: this.formatTime(amgr.currentTime),
      playDuration: this.formatTime(amgr.duration),
    };
    let progress = parseInt(amgr.currentTime * 100 / amgr.duration);
    ndata.progress = progress;
    app.globalData.playTime = this.formatTime(amgr.currentTime);
    app.globalData.playDuration = this.formatTime(amgr.duration);
    app.globalData.progress=progress;
    this.setData(ndata);
  },

  loadMore: function () {
    this.getList();
  },
  canLoadMore: function () {
    console.info('canLoadMore');
    return this.data.hasMore && !this.data.loading;
  },
  getList: function () {
    console.info('getList');
    if (this.canLoadMore()) {
      this.setData({
        loading: true
      });
      reqMgr.video.getAlbums({
        pageId: this.properties.pageId,
        pageNum: this.properties.pageNum,
        reqComplete: this.getListCB
      });
    }
  },
  parseList: function (res) {
    let pageNum = this.properties.pageNum;
    this.properties.pageNum++;
    let videos = this.data.videos;
    // let list = res.data.list;
    // console.info(list);

    let {
      list,
      nav,
      // wxrec
    } = res.data;
    let newVideos = list;//app.methods.adjustList(list, pageNum);
    let pageData = {
      'hasMore': res.data.hasmore,
      'videos': videos.concat(newVideos)
    }
    if (nav) {
      pageData.albums = nav.list;
    }
    this.setData(pageData);
    console.info(pageData);
  },
  getListCB: function (res) {
    if (res.data && res.data.list) {
      this.parseList(res);
    }
    this.setData({
      loading: false,
    });
  },


  onAlbumClick: function (event) {
    //事件源组件上由data-开头的自定义属性组成的集合
    let dataset = event.currentTarget.dataset;
    console.info(dataset);
    let id = dataset.id;
    // console.info(this.data.playName);
    let url = '/pages/subaudio/subaudio?pid=' + id + '&pName=' + dataset.name;
    // +'&album=' + dataset.name
    wx.navigateTo({ url });
  },

  onAlbumClickT: function (event) {
    //事件源组件上由data-开头的自定义属性组成的集合
    let dataset = event.currentTarget.dataset;
    console.info(dataset);
    let id = dataset.id;
   
    let url = '/pages/saudios/saudios?pid=' + id; 
    wx.navigateTo({ url });
  },

  play: function () {
    const amgr = wx.getBackgroundAudioManager();
    console.info(amgr);
    if (amgr.src) {
      amgr.play();
      this.setData({
        isPlaying: true
      });
    } else {
      var idx = (app.globalData.playIdx);

      if (idx !== -1) {
        console.info(idx);
        this.playByIdx(idx);
        // wx.getBackgroundAudioManager().startTime 
      }
    }
  },

  pause: function () {
    const amgr = wx.getBackgroundAudioManager();
    amgr.pause();
    this.setData({
      isPlaying: false
    });
  },


  playByIdx: function (idx) {
    console.info('playName:' + this.data.playName);
    // let videos = this.getSubPageVideos();
    let videos = app.globalData.videos;
    if (idx >= videos.length) {
      idx = 0;
      app.globalData.playIdx=0;
    }
    let info = videos[idx];
    if (!info) {
      return;
    }
    // this.setSubPageData({
    //   playIdx: idx
    // });
    const amgr = wx.getBackgroundAudioManager();
    amgr.title = info.name;
    amgr.singer = info.artist;
    amgr.src = info.url;

    this.setData({
      playTab: this.data.currentTab,
      // playName: info.name,
      isPlaying: true,
      // picsrc: 'http:\/\/cdnbbbd.ergeduoduo.com\/bb\/img\/album\/m750x750\/' + this.properties.pageId.slice(-3) + '\/' + this.properties.pageId +'.jpg',
    });
    this.setData({
      playName: info.name,
    });
    console.info('playName:' + this.data.playName);
    // if (this.changePage == 1) {

    // app.globalData.playName = info.name;
    // app.globalData.picsrc = 'http:\/\/cdnbbbd.ergeduoduo.com\/bb\/img\/album\/m750x750\/' + this.properties.pageId.slice(-3) + '\/' + this.properties.pageId + '.jpg';

    // app.globalData.isPlaying = true;
    // }

    app.globalData.playName = info.name;
    // app.globalData.picsrc = 'http:\/\/cdnbbbd.ergeduoduo.com\/bb\/img\/album\/m750x750\/' + this.properties.pageId.slice(-3) + '\/' + this.properties.pageId + '.jpg';

    app.globalData.isPlaying = true;






  },


  playNext: function () {
    console.info('playNexttttt!');
    // var idx = this.getSubPagePlayIdx(this.data.playTab);
    var idx = (app.globalData.playIdx++);

    if (idx !== -1) {
      console.info(idx);
      this.playByIdx(idx + 1);
    }
  },

  onEnded: function () {
    this.playNext();
  },


  buildShareUrl: function () {
    let url = '/pages/videos/videos?';
    return url;
  },
  buildShareImg: function () {
    return app.globalData.shareImg;
  },
  buildShareTitle: function () {
    return app.globalData.shareTitle;
  },
  onShareAppMessage: function (options) {
    return {
      title: this.buildShareTitle(),
      path: this.buildShareUrl(),
      imageUrl: this.buildShareImg()
    };
  },
})