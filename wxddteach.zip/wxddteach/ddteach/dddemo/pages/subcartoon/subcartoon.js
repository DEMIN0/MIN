
const app = getApp();
const reqMgr = require('../../utils/reqmgr.js');
Page({
  data: {
    hasMore: 1,
    loading: false,
    videos: [],
  },
  properties: {
    pageId: 26,
    pageNum: 0,
  },
  onLoad: function (options) {
    this.properties.pageId=options.pid;
    this.getList();
  },
  onReachBottom: function () {
    console.info('onReachBottom');
    if (this.canLoadMore()) {
      this.loadMore();
    }
  },
  loadMore: function () {
    this.getList();
  },
  canLoadMore: function () {
    console.info('canLoadMore');
    return this.data.hasMore && !this.data.loading;
  },
  getList: function () {
    console.info('getList');
    if (this.canLoadMore()) {
      this.setData({
        loading: true
      });
      reqMgr.video.getAlbumsT({
        pageId: this.properties.pageId,
        pageNum: this.properties.pageNum,
        reqComplete: this.getListCB
      });
    }
  },
  parseList: function (res) {
    let pageNum = this.properties.pageNum;
    this.properties.pageNum++;
    let videos = this.data.videos;
    // let list = res.data.list;
    // console.info(list);

    let {
      list,
      nav,
      // wxrec
    } = res.data;
    let newVideos = list;//app.methods.adjustList(list, pageNum);
    let pageData = {
      'hasMore': res.data.hasmore,
      'videos': videos.concat(newVideos)
    }
    this.setData(pageData);
    console.info(pageData);
  },
  getListCB: function (res) {
    if (res.data && res.data.list) {
      this.parseList(res);
    }
    this.setData({
      loading: false,
    });
  },


  onAlbumClick: function (event) {
    //事件源组件上由data-开头的自定义属性组成的集合
    let dataset = event.currentTarget.dataset;
    console.info(dataset);
    let id = dataset.id;
    let url = '/pages/subvideos/subvideos?pid=' + id + '&album=' + dataset.name;
    wx.navigateTo({ url });
  },

  buildShareUrl: function () {
    let url = '/pages/videos/videos?';
    return url;
  },
  buildShareImg: function () {
    return app.globalData.shareImg;
  },
  buildShareTitle: function () {
    return app.globalData.shareTitle;
  },
  onShareAppMessage: function (options) {
    return {
      title: this.buildShareTitle(),
      path: this.buildShareUrl(),
      imageUrl: this.buildShareImg()
    };
  },
})