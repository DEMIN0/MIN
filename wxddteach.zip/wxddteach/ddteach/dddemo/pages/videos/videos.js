
const reqMgr = require('../../utils/reqmgr.js');
const app = getApp();
const pageCnt = 30;
let subPages = [{
  name: '儿歌',
  type: 'video',
  pageId: app.globalData.videoListId,
  pageNum: 0,
  hasMore: 1,
  loading: false,
  videos: [],
  albums: [],
  errortry: 0,
  restype: "duoduo",
}];

Page({
  data: {
    hasMore:0,
    recPos: 0,
    recAppId: '',
    recImg: "",
    currentTab: 0,
    subPages: subPages,
    animationData: {},
  },
  properties: {
    shareInfo: null
  },
  onLoad: function (options) {
    
    this.getList();
  },
  onShow: function () {
    // this.getTabBar().setData({
    //   selected: 0
    // });

    var animation = wx.createAnimation({
      duration: 800,
      timingFunction: 'ease',
      delay: 1000
    });
    this.animation = animation;
    animation.right('-20rpx').step();
    this.setData({
      animationData: animation.export()
    });
  },
  onReachBottom: function () {
    if (this.canLoadMore(0)) {
      this.loadMore();
    }
  },
  //viewPager
  swichNav: function (e) {
    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      this.setData({
        currentTab: e.target.dataset.current
      });
    }
  },
  onPageChange: function (e) {
    let index = e.detail.current;
    let videos = this.getSubPageVideos(index);
    if (videos.length === 0) {
      this.getList(index);
    }
    this.setData({
      currentTab: index
    });
  },
  getSubPageId: function (index) {
    if (typeof index === 'undefined') {
      index = this.data.currentTab;
    }
    return this.data.subPages[index].pageId;
  },
  getSubPageNum: function (index) {
    if (typeof index === 'undefined') {
      index = this.data.currentTab;
    }
    return this.data.subPages[index].pageNum;
  },
  getSubPageMore: function (index) {
    if (typeof index === 'undefined') {
      index = this.data.currentTab;
    }
    return this.data.subPages[index].hasMore;
  },
  getSubPageLoading: function (index) {
    if (typeof index === 'undefined') {
      index = this.data.currentTab;
    }
    return this.data.subPages[index].loading;
  },
  canLoadMore: function (index) {
    if (typeof index === 'undefined') {
      index = this.data.currentTab;
    }
    return this.getSubPageMore(index) && !this.getSubPageLoading(index);
  },
  getSubPageVideos: function (index) {
    if (typeof index === 'undefined') {
      index = this.data.currentTab;
    }
    return this.data.subPages[index].videos;
  },
  setSubPageData: function (info, index) {
    if (typeof index === 'undefined') {
      index = this.data.currentTab;
    }
    let baseKey = 'subPages[' + index + '].';
    let newData = {};
    for (let key in info) {
      let k = baseKey + key;
      newData[k] = info[key];
    }
    this.setData(newData);
    // console.info(subPages[0]);
  },
  parseList: function (res, listId) {
    let pageNum = this.getSubPageNum(listId);
    let videos = this.getSubPageVideos(listId);
    let {
      list,
      nav,
      wxrec
    } = res.data;
    let hasmore = res.data.hasmore;
    
    let pageData = {
      'pageNum': pageNum + 1,
      'hasMore': hasmore,
      'videos': videos.concat(list)
    }
    
    this.setSubPageData(pageData, listId);
  },
  getListCB: function (res, listId) {
    let neterror = 0;
    if (res.data && res.data.list) {
      this.parseList(res, listId);
    } else {
      neterror = 1;
    }
    this.setSubPageData({
      loading: false,
      errortry: neterror,
    }, listId);
  },
  getList: function (index) {
    if (typeof index === 'undefined') {
      index = this.data.currentTab;
    }
    if (this.canLoadMore()) {
      this.setSubPageData({
        loading: true
      }, index);
      reqMgr.video.getListApp({
        pageId: this.getSubPageId(index),
        pageNum: this.getSubPageNum(index),
        listId: index,
        pageCnt: pageCnt,
        reqComplete: this.getListCB
      });
    }
  },
  loadMore: function () {
    this.getList();
    this.setSubPageData({
      errortry: 0
    });
  },
 
  buildPlayPageUrl: function (info, isShare) {
    let url;//= isShare ? '/pages' : '..';
    let shareUrl = '/pages/videos/videos?type=share';
    if ((info['restype'] || 'duoduo') === 'duoduo') {
      if (!!isShare) {
        url = shareUrl;
      } else {
        url = '/pages/vplayer/vplayer?type=play';
      }
      url += '&restype=duoduo';
      url += '&rid=' + info.id;
      url += '&pn=' + (!!isShare ? 0 : info.pagenum);
      url += '&pid=' + this.getSubPageId();
      url += '&hasmore=' + this.getSubPageMore();
    } else {
      if (!!isShare) {
        url = shareUrl;
      } else {
        url = '/pages/webplayer/webplayer?type=play';
      }
      url += '&vid=' + info.id
        + '&restype=' + info.restype
        + '&pid=' + this.properties.pageId
        + '&playkey=' + encodeURIComponent(info.playkey)
        + '&album=' + encodeURIComponent(this.properties.album);
    }
    return url;
  },
  onDdrecClick: function (event) {

    const amgr = wx.getBackgroundAudioManager();
    if (!!amgr) {
      amgr.pause();
    }

    let appId = event.target.dataset.appid;
    
    wx.navigateToMiniProgram({
      appId: appId,
      
      complete(res) {

      }
    })
  },
  playVideo: function (event) {
    let subpage = this.data.subPages[this.data.currentTab];
    let videos = subpage.videos;
    let curIndex = event.currentTarget.dataset.idx;
    let info = videos[curIndex];
    info['pagenum'] = subpage.pageNum;
    let url = this.buildPlayPageUrl(info, false);
    if ((info['restype'] || 'duoduo') === 'duoduo') {
      let index = curIndex % pageCnt;
      let pageNum = parseInt(curIndex / pageCnt);

      let vlist = videos.slice(pageNum * pageCnt);
      url += ('&videos=' + encodeURIComponent(JSON.stringify(vlist)));
      url += ('&index=' + index);
    }
    wx.navigateTo({
      url: url
    });
  },
  buildShareUrl: function () {
    let url = '/pages/videos/videos';
    let info = this.properties.shareInfo;
    if (info) {
      url = this.buildPlayPageUrl(info, true);
    }
    return url;
  },
  buildShareImg: function () {
    return app.globalData.shareImg;
  },
  buildShareTitle: function () {
    let info = this.properties.shareInfo;
    if (info) {
      return info.name;
    }
    return app.globalData.shareTitle;
  },
  onShareAppMessage: function (options) {
    return {
      title: this.buildShareTitle(),
      path: this.buildShareUrl(),
      imageUrl: this.buildShareImg()
    };
  },
  updateShareInfo: function (event) {
    let subpage = this.data.subPages[this.data.currentTab];
    let videos = subpage.videos;
    let info = videos[event.currentTarget.dataset.idx];
    info['pagenum'] = subpage.pageNum;
    this.properties.shareInfo = info;
    wx.updateShareMenu();
  },
  share: function (event) { },
  onAlbumClick: function (event) {
    let id = event.currentTarget.dataset.id;
    let url = '/pages/subvideos/subvideos?pid=' + id;
    wx.navigateTo({
      url
    });
  },
  goHelp: function (event) {
    let url = '/pages/help/help';
    wx.navigateTo({
      url
    });
  }
})