
const reqMgr = require('../../utils/reqmgr.js');
const app = getApp();
Page({

  data: {
    pageNum: 0,
    hasMore: 1,
    loading: false,
    videos: [],
    errortry: 0,
   
  },
  properties: {
    pageId: 29,
    album: "",
    shareInfo: null
  },
  onLoad: function (options) {
    this.properties.pageId = options.pid;
    this.properties.album = options.album;
      // console.info(this.properties.album);
    this.getList();
  },
  onReachBottom: function () {
    if (this.canLoadMore(0)) {
      this.loadMore();
    }
  },
  canLoadMore: function () {
    return this.data.hasMore && !this.data.loading;
  },
  getList: function () {
    if (this.canLoadMore()) {
      this.setData({
        loading: true,
      });
      reqMgr.video.getListL({
        pageId: this.properties.pageId,
        pageNum: this.data.pageNum,
        reqComplete: this.getListCB
      });
    }
  },
  parseList: function (res) {
    let pageNum = this.data.pageNum;
    let videos = this.data.videos;
    let list = res.data.list;
    let pinfo = list[0];
    //  console.info(pinfo);
    let newVideos = app.methods.adjustList(list, pageNum);
    //let newVideos = list;
    let pageData = {
      'pageNum': pageNum + 1,
      'hasMore': res.data.hasmore,
      'videos': videos.concat(newVideos)
    }
    this.setData(pageData);
  },
  parseListT: function (res) {
    let pageNum = this.data.pageNum;
    let videos = this.data.videos;
    let list = res.data.nav.list;
    let pinfo = list[0];
    console.info(pinfo);
    //let newVideos = app.methods.adjustList(list, pageNum);
    let newVideos = list;
    let pageData = {
      'pageNum': pageNum + 1,
      'hasMore': pinfo.hasmore,
      'videos': videos.concat(newVideos)
    }
    this.setData(pageData);
  },
  getListCB: function (res) {
    let neterror = 0;
    // if (res.data && res.data.list) {
    if (res.data && res.data.list ) {
       console.info('ssss');
      this.parseList(res);
    } else{
      // console.info('sdadad');
      // this.parseListT(res);
    }
    
    this.setData({
      loading: false,
      errortry: neterror
    });
  },
  loadMore: function () {
   console.info("1111111111");
    this.getList();
    this.setData({
      errortry: 0
    });
  },


  playVideo: function (event) {
    let videos = this.data.videos;
    // console.info(this.data);
    let curIndex = event.currentTarget.dataset.idx;
    // console.info(event.currentTarget.dataset.idx);
    let info = videos[curIndex];
    console.info('curIndex:' + curIndex);
     console.info(info);
  
    info['pagenum'] = this.data.pageNum;
    let url = this.buildPlayPageUrl(info, false);
    if ((info['restype'] || 'duoduo') === 'duoduo') {
      let index = curIndex % reqMgr.defPageCnt();
      //  console.info(index);
       let pageNum = parseInt(curIndex / reqMgr.defPageCnt());
       //let vlist = videos.slice(pageNum * reqMgr.defPageCnt());
      let vlist=videos;
      url += ('&videos=' + JSON.stringify(vlist));
      url += ('&index=' + curIndex);
      // console.info(url);
    }
    wx.navigateTo({
      url: url
    });
  },

  buildPlayPageUrl: function (info, isShare) {
    let url;//= isShare ? '/pages' : '..';
    if ((info['restype'] || 'duoduo') === 'duoduo') {
      url = '/pages/vplayer/vplayer?type=play';
      url += '&restype=duoduo';
      url += '&rid=' + info.id;
      url += '&pn=' + (!!isShare ? 0 : info.pagenum);
      url += '&pid=' + this.properties.pageId;
      url += '&hasmore=' + this.data.hasMore;
    } else {
      if (!!isShare) {
        url = shareUrl;
      } else {
        url = '/pages/webplayer/webplayer?type=play';
      }
      url += '&vid=' + info.id
        + '&restype=' + info.restype
        + '&pid=' + this.properties.pageId
        + '&playkey=' + encodeURIComponent(info.playkey)
        + '&album=' + encodeURIComponent(this.properties.album);
    }
    return url;
  },


  buildShareUrl: function () {
    let url = '/pages/videos/videos?';
    return url;
  },
  buildShareImg: function () {
    return app.globalData.shareImg;
  },
  buildShareTitle: function () {
    return app.globalData.shareTitle;
  },
  onShareAppMessage: function (options) {
    return {
      title: this.buildShareTitle(),
      path: this.buildShareUrl(),
      imageUrl: this.buildShareImg()
    };
  },
})