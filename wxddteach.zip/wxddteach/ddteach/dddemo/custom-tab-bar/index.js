const app = getApp();

Component({
  data: {
    isAllScreen: app.globalData.isAllScreen,
    selected: 0,
    "color": "#9da0a5",
    "selectedColor": "#5ABFFF",
    "backgroundColor": "#fff",


    "list": [
      {
        "pagePath": "/pages/videos/videos",
        "text": "早教·课件",
        "iconPath": "../img/ic_game_normal.png",
        "selectedIconPath": "../img/ic_game_selected.png"
      },
      {
        "pagePath": "/pages/english/english",
        "text": "英语·启蒙",
        "iconPath": "../img/ic_english_normal.png",
        "selectedIconPath": "../img/ic_english_selected.png"
      },
      {
        "pagePath": "/pages/audios/audios",
        "text": "宝宝听",
        "iconPath": "../img/ic_listen_normal.png",
        "selectedIconPath": "../img/ic_listen_selected.png"
      },
      {
        "pagePath": "/pages/talent/talent",
        "text": "国学·才艺",
        "iconPath": "../img/ic_talent_normal.png",
        "selectedIconPath": "../img/ic_talent_selected.png"
      },
      {
        "pagePath": "/pages/cartoon/cartoon",
        "text": "动画·儿歌",
        "iconPath": "../img/ic_cartoon_normal.png",
        "selectedIconPath": "../img/ic_cartoon_selected.png"
      }
    ]
  },
  attached() {
  },
  methods: {
    switchTab(e) {
      const data = e.currentTarget.dataset;
      console.info(data);
      const url = data.path;
      wx.switchTab({url});
      // this.setData({
      //   selected: data.index
      // });
    }
  }
})