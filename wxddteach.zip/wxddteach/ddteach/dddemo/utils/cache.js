const cache = {
  baseKey: 'cache_',
  expireTime: 6 * 60 * 60 * 1000,

  checkLimit: function () {
    wx.getStorageInfo({
      success: function (res) {
        // console.info(res);
        if (res.limitSize - res.currentSize < 512) {
          wx.clearStorage();
        }
      }
    });
  },

  buildKey: function (key) {
    return this.baseKey + key;
  },
  buildExpireKey: function (key) {
    return this.buildKey(key) + '_expire';
  },

  isEmpty: function (obj) {
    for (let k in obj) {
      
      return false;
    }
    return true;
  },
 
  isValid: function (key) {
    let ek = this.buildExpireKey(key);
    //  console.info(ek);
    let ctime = wx.getStorageSync(ek);
    // console.info(ctime);
    if (!ctime) {
      return false;
    }
    let ndate = new Date();
    // console.info(ndate);
    let ntime = ndate.getTime();
    // console.info(ntime);
   
    return ntime - ctime < this.expireTime;
  },

  set: function (key, obj) {
    console.info('key: '+key);
    if (obj && !this.isEmpty(obj)) {
      let ck = this.buildKey(key);
      let ek = this.buildExpireKey(key);
      let cdate = new Date();
      let ctime = cdate.getTime();
      
      wx.setStorage({
        key: ck,
        data: obj
      });
      wx.setStorage({
        key: ek,
        data: ctime
      });
    }
  },

  get: function (key) {
    let obj = null;
     //console.info(this.isValid(key));
     if (this.isValid(key)) {
      let ck = this.buildKey(key);
      console.info(ck);
      obj = wx.getStorageSync(ck);
      //  console.info(obj);
     }
     //首次加载obj=null
    return obj;
  }
};

module.exports = cache;