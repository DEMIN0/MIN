const app = getApp();
const cache = require('cache.js')
const DEF_PAGE_COUNT = 30;

const reqMgr = {
  defPageCnt() {
    return DEF_PAGE_COUNT;
  },
  video: {

    getReqParamZ: function (pageId, pageNum, pageCnt) {
      return {
       // type: 'getvideos',
        act:'getalbumlist',
        pg: pageNum,
        ps: pageCnt,
        pid: pageId,
        // srcver: 'story',
        // grade: '-1_-1',
        interver: 5
      };
    },
    getReqParamL: function(pageId, pageNum, pageCnt) {
      return {
        act: 'getlist',

        pg: pageNum,
        ps: pageCnt,
        pid: pageId,
      
        interver: 5
      };
    },
    getReqParam: function (pageId, pageNum, pageCnt) {
      return {
        act: 'getlist',
       
        ps: pageNum,
        ps: pageCnt,
        pid: pageId,
        srcver: 'story',
        grade: '-1_-1',
        interver: 5
      };
    },



    getAlbumsT: function ({
      pageId,
      pageNum = 0,
      pageCnt = DEF_PAGE_COUNT,
      reqComplete,
      listId = 0
    }) {
      console.info('getAlbumsT');
      let ck = ['albumsv_2', pageId, pageNum, pageCnt, 2].join('_');
      console.info('ck: ' + ck);
      let c = cache.get(ck);
      console.info(c);
      //首次加载c==null
      if (c) {
        console.info('非首次加载');
        if (reqComplete) {
          reqComplete(c, listId);
        }
      } else {//首次加载时运行
        console.info('首次加载');
        let param = this.getAlbumsParamT(pageId, pageNum, pageCnt);
        console.info(param);
        wx.request({
          // url: app.globalData.baseUrl2,
          url: 'https://edu.ergeduoduo.com/ddedu/api/v1/list.php',
          data: param,//请求参数
          complete: function (res) {
            console.info(res);
            if (res.statusCode == 200 && res.data) {
              cache.set(ck, res);
            }
            if (reqComplete) {
              //console.info(listId);
              //  listId=0;
              reqComplete(res, listId);
            }
          }
        });
      }
    },

    getAlbumsParamT: function (pageId, pageNum, pageCnt) {
      return {
        act: 'getalbumlist',
        pg: pageNum,
        ps: pageCnt,
        pid: pageId,
        ver: 2,
      };
    },
    
    getAlbums: function ({
      pageId,
      pageNum = 0,
      pageCnt = DEF_PAGE_COUNT,
      reqComplete,
      listId = 0
    }) {
      console.info('getAlbums');
      let ck = ['albumsv_2', pageId, pageNum, pageCnt, 2].join('_');
      console.info('ck: '+ck);
      let c = cache.get(ck);
       console.info(c);
       //首次加载c==null
      if (c) {
        console.info('非首次加载');
        if (reqComplete) {
          reqComplete(c, listId);
        }
      } else {//首次加载时运行
      console.info('首次加载');
        let param = this.getAlbumsParam(pageId, pageNum, pageCnt);
        console.info(param);
        wx.request({
          // url: app.globalData.baseUrl2,
          url:'https://edu.ergeduoduo.com/ddedu/api/v1/list.php',
          data: param,//请求参数
          complete: function (res) {
            console.info(res);
            if (res.statusCode == 200 && res.data) {
              cache.set(ck, res);
            }
            if (reqComplete) {
              //console.info(listId);
              //  listId=0;
              reqComplete(res, listId);
            }
          }
        });
      }
    },

    getAlbumsParam: function (pageId, pageNum, pageCnt) {
      return {
        act: 'getalbumlist',
        pg: pageNum,
        ps: pageCnt,
        pid: pageId,
        ver: 2,
      };
    },

    getListZ: function ({
      pageId,
      pageNum = 0,
      pageCnt = DEF_PAGE_COUNT,
      reqComplete,
      listId = 0
    }) {
      console.info('getListZ');
      let ck = ['videosv2', pageId, pageNum, pageCnt, 5].join('_');
      let c = cache.get(ck);
      console.info(c);
      if (c) {
        if (reqComplete) {
          reqComplete(c, listId);
        }
      } else {
        let param = this.getReqParamZ(pageId, pageNum, pageCnt);
        console.info(param);
        wx.request({
          // url: app.globalData.baseUrl,
           
          url: 'https://edu.ergeduoduo.com/ddedu/api/v1/list.php?',
          data: param,
          complete: function (res) {
           
            console.info(res);
            // if (res.statusCode == 200 && res.data) {
            //   cache.set(ck, res);
            // }
            if (reqComplete) {
              // console.info(listId);
              reqComplete(res, listId);
            }
          }
        });
      }
    },

    getListApp: function ({
      pageId,
      pageNum = 0,
      pageCnt = DEF_PAGE_COUNT,
      reqComplete,
      listId = 0
    }) {
      let ck = ['appsv2', pageId, pageNum, pageCnt, 5].join('_');
      let c = cache.get(ck);
      if (c) {
        if (reqComplete) {
          reqComplete(c, listId);
        }
      } else {
        let param = this.getReqParam(pageId, pageNum, pageCnt);
        wx.request({
          // url: app.globalData.baseUrl,
          // data: param,
          url: 'https://bb.ergeduoduo.com/ddedu/ddedu.php?act=glist',
          complete: function (res) {
            console.info(res);
            // wx.hideLoading();
            if (res.statusCode == 200 && res.data) {
              cache.set(ck, res);
            }
            if (reqComplete) {
              reqComplete(res, listId);
            }
          }
        });
      }
    },

    getListL: function ({
      pageId,
      pageNum ,
      pageCnt = DEF_PAGE_COUNT,
      reqComplete,
      listId = 0
    }) {
      console.info('getListL:');
      let ck = ['videosv2', pageId, pageNum, pageCnt, 5].join('_');
      let c = cache.get(ck);
      if (c) {
        if (reqComplete) {
          reqComplete(c, listId);
        }
      } else {
        let param = this.getReqParamL(pageId, pageNum, pageCnt);
        console.info(param);
        wx.request({
         //url: app.globalData.baseUrl,
          url:'https://edu.ergeduoduo.com/ddedu/api/v1/list.php',
          data: param,
          complete: function (res) {

            console.info(res);
         
            if (reqComplete) {
              // console.info(listId);
              reqComplete(res, listId);
            }
          }
        });
      }
    },

    getList: function ({
      pageId,
      pageNum = 0,
      pageCnt = DEF_PAGE_COUNT,
      reqComplete,
      listId = 0
    }) {
      console.info('getList');
      let ck = ['videosv2', pageId, pageNum, pageCnt, 5].join('_');
      let c = cache.get(ck);
      console.info(c);
      if (c) {
        if (reqComplete) {
          reqComplete(c, listId);
        }
      } else {
        let param = this.getReqParam(pageId, pageNum, pageCnt);
        console.info(param);
        wx.request({
           url: app.globalData.baseUrl,
          //url:'http://edu.ergeduoduo.com/ddedu/api/v1/list.php?act=getlist&pid=10000229',
          data: param,
          complete: function (res) {

            console.info(res);
            if (res.statusCode == 200 && res.data) {
              cache.set(ck, res);
            }
            if (reqComplete) {
              // console.info(listId);
              reqComplete(res, listId);
            }
          }
        });
      }
    },


    getPlayParam: function (rid, callback) {
      return {
        type: 'getplayurl',
        method: 15,
        rid: rid
      };
    },
    getPlayUrl: function (rid, reqComplete) {
      let param = this.getPlayParam(rid);
      wx.request({
        url: app.globalData.baseUrl,
        data: param,
        complete: function (res) {
          if (reqComplete) {
            reqComplete(res);
          }
        }
      });
    }
   
  },

  audio: {
    getReqParam: function (pageId, pageNum, pageCnt) {
      return {
        act: 'getlist',
        pg: pageNum,
        ps: pageCnt,
        pid: pageId,
        srcver: 'story'
      };
    },
    getList: function (paramObj) {
      let pageId = paramObj.pageId;
      let pageNum = paramObj.pageNum || 0;
      let pageCnt = paramObj.pageCnt || DEF_PAGE_COUNT;
      let reqComplete = paramObj.reqComplete;
      let listId = paramObj.listId || 0;
      
      let ck = ['audios', pageId, pageNum, pageCnt].join('_');
      console.info('cccck:'+ck);
      let c = cache.get(ck);
      if (c) {
        if (reqComplete) {
          reqComplete(c, listId);
        }
      } else {
        let param = this.getReqParam(pageId, pageNum, pageCnt);
        wx.request({
          url: 'https://edu.ergeduoduo.com/ddedu/api/v1/list.php',
          data: param,
          complete: function (res) {
            console.info('res:');
            console.info(res);
            // if (res.statusCode == 200 && res.data) {
            //   cache.set(ck, res);
            // }
            if (reqComplete) {
              reqComplete(res, listId);
            }
          }
        });
      }
    }
  }
};

module.exports = reqMgr;